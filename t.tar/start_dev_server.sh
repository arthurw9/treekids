python3 flask_app.py

